---
title: MRHyperlink
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/core/entities/MRHyperlink.js
---
# MRHyperlink

## Classes

<dl>
<dt><a href="#MRHyperlink">MRHyperlink</a> ⇐ <code>MRTextEntity</code></dt>
<dd><p>3D representation of a hyperlink. <code>mr-a</code></p>
</dd>
</dl>

## Functions

<dl>
<dt><a href="#connected">connected()</a></dt>
<dd></dd>
</dl>

<a name="MRHyperlink"></a>

## MRHyperlink ⇐ <code>MRTextEntity</code>
3D representation of a hyperlink. `mr-a`

**Kind**: global class  
**Extends**: <code>MRTextEntity</code>  
<a name="connected"></a>

## connected()
**Kind**: global function  
