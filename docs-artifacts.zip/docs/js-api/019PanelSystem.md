---
title: PanelSystem
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/core/componentSystems/PanelSystem.js
---
# PanelSystem

<a name="PanelManagementSystem"></a>

## PanelManagementSystem ⇐ <code>MRSystem</code>
A system that manages the screen relative position of UI panels

**Kind**: global class  
**Extends**: <code>MRSystem</code>  
