---
title: MRVolume
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/core/entities/MRVolume.js
---
# MRVolume

