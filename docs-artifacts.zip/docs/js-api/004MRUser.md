---
title: MRUser
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/core/user/MRUser.js
---
# MRUser

