---
title: MRPlane
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/dataTypes/MRPlane.js
---
# MRPlane

<a name="MRPlane"></a>

## MRPlane
a name space representation of an MR Plane

**Kind**: global class  
