---
title: Refractor
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/extras/Refractor.js
---
# Refractor

