---
title: Water
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/extras/Water.js
---
# Water

<a name="Water"></a>

## Water
References:
	https://alex.vlachos.com/graphics/Vlachos-SIGGRAPH10-WaterFlow.pdf
	http://graphicsrunner.blogspot.de/2010/08/water-using-flow-maps.html

**Kind**: global class  
