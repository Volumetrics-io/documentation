---
title: Display
github-path: https://github.com/volumetrics-io/mrjs/edit/main/src/utils/Display.js
---
# Display

<a name="display"></a>

## display : <code>object</code>
Useful namespace for helping with Display utility functions

**Kind**: global namespace  
<a name="display.VIRTUAL_DISPLAY_RESOLUTION"></a>

### display.VIRTUAL\_DISPLAY\_RESOLUTION
Defaults to 1080;

**Kind**: static property of [<code>display</code>](#display)  
